#!/bin/bash

echo Running tests with Lambda and Batch in $AWS_REGION region
if [[ -f ~/envVars-$AWS_REGION ]]; then 
  source ~/envVars-$AWS_REGION
else # in CloudBuild environment
  INPUT_BUCKET=fsi-demo-$AWS_REGION-$(echo ${CODEBUILD_BUILD_ARN} | cut -d\: -f5)
fi

# Check if the bucket exists
if ! aws s3 ls $INPUT_BUCKET; then echo please create bucket $INPUT_BUCKET; exit; fi

date;aws s3 cp Data/EquityOption-100.csv s3://$INPUT_BUCKET/fast/100/
date;aws s3 cp Data/EquityOption-100.csv s3://$INPUT_BUCKET/normal/100/
