# FSI-demo

# Description
This project demonstrates how to build infrastructure on AWS quickly for loosely-coupled applications. Lambda is used for fast-turnaround, and AWS Batch scales with tens of thousands of vCPUs cost-effectively. Quantlib [1] is used to value American Options with Monte-Carlo simulations. The system can be used to run other Linux-compatible binaries or scripts as well by updating the "program" variable in the bootstrap file. The default program variable value "EquityOption" can be overwritten by the environment variable of Batch or Lambda.

Ref [1]: https://www.quantlib.org/

# Usage
The core part of the simulations is executed in the function.sh file with a generic format for similar applications:
```
program inputFile
```

# Step 0: Clone the code repository and (optionally) setup the region
```
git clone https://gitlab.aws.dev/yusongw/fsi-ab.git ./fsi-demo
cd fsi-demo
export AWS_REGION=us-east-2 #optional. If not set, the same region of cloud9 instance will be used
```
# Step 1: Create Amazon ECR repositories and store the container images for the first time. Then update the container images with the same script afterwards.
```
./updateImage.sh
```
# Step 2: Build infrastructures with cloudformation for S3, Lambda and Batch, etc..
```
./buildArch.sh
```

# Step 3: Run quick tests
```
./test.sh
```

# Optional steps to build the QuantLib Binary (an instance with 8GB memory is recommended). 
  1) Follow the instructions from QuantLib installation page: https://www.quantlib.org/install/linux.shtml -- QuantLib 1.27.1 is used for this experiment 
  2) Replace the Examples/EquityOption/EquityOption.cpp file with the one from this repo to run multiple American Options simulations in one job
  3) Copy the binary from Examples/EquityOption/.libs/lt-EquityOption (generated after running Examples/EquityOption/EquityOption) as Application/EquityOption in the repo and ql/.libs/libQuantLib.so.0 to Application/.libs/ in the repo. 

