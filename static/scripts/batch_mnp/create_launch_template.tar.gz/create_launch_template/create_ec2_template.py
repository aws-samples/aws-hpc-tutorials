# Load the Template and replace teh values in teh dictionary
import json
import base64
from dict_merge import dict_merge


def load_template(ec2_template_config_fname):
    with open(ec2_template_config_fname, 'r') as fp:
        ret_dict = json.load(fp)

    return ret_dict


def encode_user_data(mime_file):
    with open(mime_file, "rb") as f:
        read_data = f.read()
        user_data = base64.b64encode(read_data)
        ret_dict = {
            "LaunchTemplateData": {
                "UserData": str(user_data)[2:-1]
            }
        }
        return ret_dict


if __name__ == "__main__":
    ec2_template_dict = load_template('./template/ec2-template-config.json')

    # Start replacing the sections in each of them
    with open('./override_dict.json', 'r') as fp:
        override_dict = json.load(fp)
    out_ec2_dict = dict_merge(ec2_template_dict, override_dict)

    # template_user_data = encode_user_data('./template/fsx_launch_template.yml')
    template_user_data = encode_user_data('./template/efs_ecs_launch_template.yml')
    out_ec2_dict = dict_merge(out_ec2_dict, template_user_data)

    with open('export_dict.json', 'w') as fp:
        json.dump(out_ec2_dict, fp, indent=2)
