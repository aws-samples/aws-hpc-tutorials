import random, os, argparse
from create_pretraining_data import create_training_instances, write_instance_to_example_file


def load_and_write_hf(output_dir):
    """Load wikitext2 from hugging face dataset library and save it as a token file

    Args:
        output_dir (str): Directory that will store wikitext2 dataset

    Returns:
        str: Wikitext2 token file path
    """
    from datasets import load_dataset

    dataset = load_dataset("wikitext", "wikitext-2-v1",split="train")
    formatted_dataset = ''.join([d['text'] for d in dataset])

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    token_name = "wikitext-2-hf_train.token"
    f_path = os.path.join(output_dir, token_name)

    f = open(f_path,"w")
    f.write(formatted_dataset)
    f.close()

    return f_path

def load_and_write_s3(output_dir):
    """Load wikitext2 from S3 dataset and save it as a token file. S3 Path found through d2l Library Data_Hub
    https://d2l.ai/chapter_natural-language-processing-pretraining/bert-dataset.html#the-dataset-for-pretraining-bert

    Args:
        output_dir (str): Directory that will store wikitext2 dataset

    Returns:
        str: Wikitext2 token file path
    """
    import urllib.request
    import zipfile

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    url_download_path = "https://s3.amazonaws.com/research.metamind.io/wikitext/wikitext-2-v1.zip"
    output_zip_path   = f"{output_dir}/wikitext-2-v1.zip"
    urllib.request.urlretrieve(url_download_path, output_zip_path)

    fp = zipfile.ZipFile(output_zip_path, 'r')
    fp.extractall(output_dir)

    data_dir = fp.namelist()[0]
    f_name   = os.path.join(output_dir, data_dir, 'wiki.train.tokens')

    return f_name


def preprocessing(input_file,
                    output_dir, 
                    max_seq_length,
                    dupe_factor, 
                    short_seq_prob,
                    masked_lm_prob,
                    max_predictions_per_seq,
                    rng):
    """Tokenize and process wikitext2 data into a hdf5 format ready for BERT training

    Args:
        input_file (str): Path to wikitext2 Token file
        output_dir (str): Output location to *.hdf5 file
        max_seq_length (int): Maximum total input sequence length after WordPiece tokenization
        dupe_factor (int): Number of times to duplicate the input data (with different masks)
        short_seq_prob (float): Probability to create a sequence shorter than maximum sequence length
        masked_lm_prob (float): Masked LM probability
        max_predictions_per_seq (float): Maximum prediction sequence length.
        rng (int): Random seed for initialization
    """
    from transformers import BertTokenizer

    output_file = os.path.join(output_dir, "wikitext-2_training.hdf5")
    tokenizer   = BertTokenizer.from_pretrained('bert-base-uncased')

    instances = create_training_instances(
        [input_file], tokenizer, max_seq_length, dupe_factor,
        short_seq_prob, masked_lm_prob, max_predictions_per_seq,
        rng)

    write_instance_to_example_file(instances, tokenizer, max_seq_length,
                                    max_predictions_per_seq, output_file)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument("--download_source",
                        default="hugging_face",
                        choices=["hugging_face", "s3"],
                        required=False,
                        help="Download Source for wikitext2")
    parser.add_argument("--output_dir",
                        default=".",
                        type=str,
                        required=False,
                        help="The output directory where the h5py will be written")
    parser.add_argument("--max_seq_length",
                        default=128,
                        type=int,
                        help="The maximum total input sequence length after WordPiece tokenization. \n"
                             "Sequences longer than this will be truncated, and sequences shorter \n"
                             "than this will be padded.")
    parser.add_argument("--dupe_factor",
                        default=10,
                        type=int,
                        help="Number of times to duplicate the input data (with different masks).")
    parser.add_argument("--max_predictions_per_seq",
                        default=20,
                        type=int,
                        help="Maximum prediction sequence length.")

    parser.add_argument("--masked_lm_prob",
                            default=0.15,
                            type=float,
                            help="Masked LM probability.")
    parser.add_argument("--short_seq_prob",
                        default=0.1,
                        type=float,
                        help="Probability to create a sequence shorter than maximum sequence length")
    parser.add_argument('--random_seed',
                        type=int,
                        default=12345,
                        help="random seed for initialization")

    args = parser.parse_args()

    if args.download_source == "hugging_face":
        token_path = load_and_write_hf(args.output_dir)
    elif args.download_source == "s3":
        token_path = load_and_write_s3(args.output_dir)

    rng = random.Random(args.random_seed)
    preprocessing(input_file                = token_path,
                    output_dir              = args.output_dir,
                    max_seq_length          = args.max_seq_length,
                    dupe_factor             = args.dupe_factor, 
                    short_seq_prob          = args.short_seq_prob, 
                    masked_lm_prob          = args.masked_lm_prob,
                    max_predictions_per_seq = args.max_predictions_per_seq, 
                    rng                     = rng)
