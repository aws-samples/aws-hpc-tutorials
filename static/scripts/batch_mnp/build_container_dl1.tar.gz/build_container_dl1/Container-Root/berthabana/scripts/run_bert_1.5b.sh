#!/bin/bash

###############################################################################################
# Example: Pretraining phase 1 of BERT with 1.5B parameters on single HLS1 box with 8 devices.
###############################################################################################

# Params: run_pretraining
ifname=eth0
MULTI_HLS_IPS=$(hostname -i)
EFS_FOLDER=/mnt/efs
SHARED_FOLDER=${EFS_FOLDER}
data_dir=${SHARED_FOLDER}/hdf5_dataset
DATA_DIR=${data_dir}/hdf5_lower_case_1_seq_len_128_max_pred_20_masked_lm_prob_0.15_random_seed_12345_dupe_factor_5/wikicorpus_en
#DATA_DIR=/software/lfs/data/pytorch/bert/pretraining/hdf5_lower_case_1_seq_len_128_max_pred_20_masked_lm_prob_0.15_random_seed_12345_dupe_factor_5/books_wiki_en_corpus
MODEL_CONFIG=./bert_1.5b_config.json
DS_CONFIG=./deepspeed_config_bert_1.5b.json
HOSTSFILE=/tmp/hostfile
RESULTS_DIR=../results/bert_1.5b
MAX_SEQ_LENGTH=128
NUM_STEPS_PER_CP=1000000
MAX_STEPS=155000
LR=0.0015
WARMUP=0.05
CONST=0.25
HMP=""
#HMP="--hmp --hmp_bf16=./ops_bf16_bert_pt.txt --hmp_fp32=./ops_fp32_bert_pt.txt"

# Params: DeepSpeed
NUM_NODES=1
NGPU_PER_NODE=8

DIR=$(cd -P -- "$(dirname -- "$0")" && pwd -P)
CMD="source $QNPU_PATH/activate ; \
     cd $DIR && \
     python -u ../run_pretraining.py \
     $HMP \
     --use_hpu \
     --warmup_proportion=$WARMUP \
     --constant_proportion=$CONST \
     --resume_from_checkpoint \
     --do_train \
     --bert_model=bert-base-uncased \
     --config_file=$MODEL_CONFIG \
     --json-summary=$RESULTS_DIR/dllogger.json \
     --output_dir=$RESULTS_DIR/checkpoints \
     --seed=12439 \
     --optimizer=nvlamb \
     --use_lr_scheduler \
     --input_dir=$DATA_DIR \
     --max_seq_length $MAX_SEQ_LENGTH \
     --max_predictions_per_seq=20 \
     --max_steps=$MAX_STEPS \
     --num_steps_per_checkpoint=$NUM_STEPS_PER_CP \
     --learning_rate=$LR \
     --deepspeed \
     --deepspeed_config=$DS_CONFIG"

#Configure multinode
if [ "$NUM_NODES" -ne "1" -a -f "$HOSTSFILE" ]
then
    MULTINODE_CMD="--hostfile=$HOSTSFILE"
fi

mkdir -p $RESULTS_DIR
deepspeed --num_nodes ${NUM_NODES} \
          --num_gpus ${NGPU_PER_NODE} \
          --master_addr ${MULTI_HLS_IPS} \
          --no_local_rank \
          --no_python \
          $MULTINODE_CMD \
          /usr/bin/bash -c "$CMD" 2>&1 | tee $RESULTS_DIR/train_log.txt
