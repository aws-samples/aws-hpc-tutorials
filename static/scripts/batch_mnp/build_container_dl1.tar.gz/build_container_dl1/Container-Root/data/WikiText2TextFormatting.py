# Copyright (c) 2019 NVIDIA CORPORATION. All rights reserved.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import glob

class WikiText2TextFormatting:
    def __init__(self, wiki_path, output_filename, recursive = False):
        self.wiki_path = wiki_path
        self.recursive = recursive
        self.output_filename = output_filename

        self.headers = [' =' * i for i in range(1,6)]
        self.H1 = self.headers[0]


    # This puts one Text per line
    def merge(self):
        with open(self.output_filename, mode='w', newline='\n') as ofile:
            for filename in glob.glob(self.wiki_path + '/**/*.tokens', recursive=True):
                with open(filename, mode='r', encoding='utf-8-sig', newline='\n') as file:
                    article_lines = []
                    file.readline()
                    for line in file:
                        # Start of an article
                        if line.count(self.H1) == 2:
                            for oline in article_lines:
                                if oline != '\n':
                                    ofile.write(oline.rstrip() + " ")
                            ofile.write("\n\n")
                            article_lines = []
                        elif not self.check_header(line):
                            article_lines.append(line)

                    # Capture the Last article
                    for oline in article_lines:
                        if oline != '\n':
                            ofile.write(oline.rstrip() + " ")
                        ofile.write("\n\n")
                        article_lines = [line]

    # Checks to see if this is an article header based on " = = " format
    def check_header(self, line):
        is_header = any(line.count(h) == i+1 for i,h in enumerate(self.headers))
        return is_header
