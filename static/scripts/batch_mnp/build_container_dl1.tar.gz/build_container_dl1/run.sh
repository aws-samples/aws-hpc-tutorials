#!/bin/bash

source ./config.properties

echo ""
echo "Run Container in Daemon mode"
docker run -td --name pt-bert --privileged --env HABANA_VISIBLE_DEVICES=all --net=host --env OMPI_MCA_btl_vader_single_copy_mechanism=none --env HCCL_OVER_TCP=0 --env HCCL_OVER_OFI=1 --env SOCKET_NTHREADS=2 --env NSOCK_PERTHREAD=3 --env FI_PROVIDER=efa  --ipc=host -v /mnt/efs:/mnt/efs -v /mnt/lustre:/mnt/lustre  -v /var/log/habana_logs:/var/log/habana_logs  --name ${image_name} ${registry}${image_name}${image_tag}
